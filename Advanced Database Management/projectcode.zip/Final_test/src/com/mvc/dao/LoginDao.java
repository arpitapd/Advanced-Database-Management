//LoginDao.java
package com.mvc.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.mvc.bean.LoginBean;
import com.mvc.util.DBConnection;

public class LoginDao {
	public String authenticateUser(LoginBean loginBean) {
		String userName = loginBean.getUserName(); 
		
		Connection con = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String userNameDB = "";
		
		try {
			con = DBConnection.createConnection(); 
			statement = con.createStatement(); 
			resultSet = statement.executeQuery("match (u:Users) return u.UserID;"); 
			while (resultSet.next()) 
			{
				userNameDB = resultSet.getString("u.UserID"); 
				
				if (userName.equals(userNameDB)) {
					return "SUCCESS";
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "Invalid user credentials"; 
	}
	
	public String findMovie(LoginBean loginBean) {
		String movieName = loginBean.getMovieTitle(); 
		
		Connection con = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String movieNameDB = "";
		
		try {
			con = DBConnection.createConnection(); 
			statement = con.createStatement(); 
			resultSet = statement.executeQuery("select TitleName from Title where TitleName LIKE"+movieName); 
			while (resultSet.next()) 
			{
				movieNameDB = resultSet.getString("movieTitle"); 
				return movieNameDB;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "Invalid user credentials"; 
	}
}