package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mvc.bean.LoginBean;
import com.mvc.dao.LoginDao;

public class SearchServlet extends HttpServlet {
	public SearchServlet() {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String movieName = request.getParameter("moviename");
		LoginBean loginBean = new LoginBean(); 
		loginBean.setUserName(movieName); 
		
		LoginDao loginDao = new LoginDao(); 
		String movieSearch = loginDao.findMovie(loginBean); 
		request.setAttribute("movieName", movieName); 
		request.getRequestDispatcher("/Home.jsp").forward(request, response);
		
	}
}
