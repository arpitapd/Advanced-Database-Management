
package com.mvc.util;


import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	public static Connection createConnection() {
		Connection con = null;
		
		String url = "jdbc:neo4j:bolt://localhost:7687/"; 
		String username = "neo4j"; 
		String password = "test12";
		try {
			try {
				Class.forName("org.neo4j.jdbc.bolt.BoltDriver"); 
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			con = DriverManager.getConnection(url, username, password); 
			System.out.println("Printing connection object " + con);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
}
